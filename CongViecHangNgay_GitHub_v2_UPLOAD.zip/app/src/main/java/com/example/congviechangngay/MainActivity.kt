package com.example.congviechangngay

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.LocalDate

enum class Shift(val label:String,val start:Int,val end:Int) {
    MORNING("Ca sáng",6,14), OFFICE("Ca hành chính",8,17),
    AFTERNOON("Ca chiều",14,22), NIGHT("Ca đêm",22,6)
}
data class Task(val id:Int,val title:String,val done:Boolean=false)
data class Todo(val id:Int,val text:String,val due:String,val progress:Int=0,val done:Boolean=false)

val taskNames=listOf(
"Chấm công đầu giờ","Khai báo nhân sự lên 2 nhóm","Kiểm tra Checksheet và ký",
"Phân chia công việc và tính làm thêm","Nhập file theo dõi làm thêm và AMH",
"Khai làm thêm trên hệ thống","Kiểm tra hàng xuất","Chốt lô / báo cáo hoàn thành lô bằng mail",
"Kiểm tra hàng DATA","Check mail và xử lý thông tin liên quan","Kiểm tra vệ sinh, 3S, 3D",
"Kiểm tra tồn kho thùng, bao bì, kệ gỗ","Tính nhân sự ngày nghỉ và sang tuần",
"Khai ca nhân sự tuần sau và OT ngày nghỉ","Kiểm tra giao hàng bóc tách",
"Kiểm tra hàng không ngày mai","Kiểm tra hiểu biết về bất thường và tuân thủ",
"Kiểm tra Todo List và vấn đề chưa giải quyết"
)

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        setContent { App(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(ctx:Context){
    val prefs=ctx.getSharedPreferences("cvhn",Context.MODE_PRIVATE)
    var shift by remember{mutableStateOf(prefs.getString("shift","")?:"")}
    var showShift by remember{mutableStateOf(shift.isBlank())}
    var tab by remember{mutableIntStateOf(0)}
    var tasks by remember{mutableStateOf(taskNames.mapIndexed{i,n->Task(i+1,n)})}
    var todos by remember{mutableStateOf(listOf<Todo>())}
    var todoText by remember{mutableStateOf("")}
    var due by remember{mutableStateOf("")}
    var prog by remember{mutableFloatStateOf(0f)}
    val done=tasks.count{it.done}
    val today=LocalDate.now().toString()
    val overdue=todos.count{!it.done&&it.due.isNotBlank()&&it.due<today}
    val dueToday=todos.count{!it.done&&it.due==today}

    if(showShift) AlertDialog(
        onDismissRequest={},
        title={Text("Hôm nay bạn đi ca gì?")},
        text={Column{Shift.values().forEach{s->
            TextButton(onClick={
                shift=s.label
                prefs.edit().putString("shift",s.label).apply()
                showShift=false
            },Modifier.fillMaxWidth()){
                Text("${s.label}: %02d:00 - %02d:00".format(s.start,s.end))
            }
        }}},
        confirmButton={}
    )

    Scaffold(
        topBar={TopAppBar(title={Text("Công Việc Hằng Ngày")},actions={
            TextButton(onClick={showShift=true}){Text(shift.ifBlank{"Chọn ca"})}
        })},
        bottomBar={NavigationBar{
            NavigationBarItem(tab==0,{tab=0},{},label={Text("Hôm nay")})
            NavigationBarItem(tab==1,{tab=1},{},label={Text("Nhắc việc")})
            NavigationBarItem(tab==2,{tab=2},{},label={Text("Tổng quan")})
        }}
    ){pad->
        when(tab){
            0->LazyColumn(Modifier.padding(pad).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                item{Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){
                    Text("Ca: $shift",style=MaterialTheme.typography.titleMedium)
                    Text("18 công việc • 30 phút/việc")
                    Text("Đã hoàn thành: $done/18 (${done*100/18}%)")
                    LinearProgressIndicator({done/18f},Modifier.fillMaxWidth())
                }}}
                items(tasks,key={it.id}){t->Card(Modifier.fillMaxWidth()){
                    Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                        Checkbox(t.done,{v->tasks=tasks.map{x->if(x.id==t.id)x.copy(done=v)else x}})
                        Text("${t.id}. ${t.title}",Modifier.weight(1f))
                    }
                }}
            }
            1->Column(Modifier.padding(pad).padding(12.dp)){
                Text("🔔 Nhắc việc & tồn đọng",style=MaterialTheme.typography.headlineSmall)
                Text("Quá hạn: $overdue • Đến hạn hôm nay: $dueToday")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(todoText,{todoText=it},Modifier.fillMaxWidth(),label={Text("Vấn đề cần theo dõi")})
                OutlinedTextField(due,{due=it},Modifier.fillMaxWidth(),label={Text("Hạn hoàn thành YYYY-MM-DD")})
                Text("Tiến độ: ${prog.toInt()}%")
                Slider(prog,{prog=it},0f..100f,steps=3)
                Button(onClick={
                    if(todoText.isNotBlank()){
                        todos=todos+Todo(todos.size+1,todoText,due,prog.toInt())
                        todoText=""; due=""; prog=0f
                    }
                },Modifier.fillMaxWidth()){Text("Thêm tồn đọng")}
                Spacer(Modifier.height(10.dp))
                LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
                    items(todos,key={it.id}){x->
                        val late=!x.done&&x.due.isNotBlank()&&x.due<today
                        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){
                            Text(if(late)"🔴 QUÁ HẠN" else if(x.due==today&&!x.done)"🟠 ĐẾN HẠN HÔM NAY" else "🟡 ĐANG THEO DÕI")
                            Text(x.text,style=MaterialTheme.typography.titleMedium)
                            Text("Hạn: ${x.due.ifBlank{"Chưa đặt"}} • Tiến độ: ${x.progress}%")
                            Row{
                                Button(onClick={todos=todos.map{t->if(t.id==x.id)t.copy(done=true,progress=100)else t}}){Text("Xong")}
                                Spacer(Modifier.width(8.dp))
                                OutlinedButton(onClick={
                                    val i=Intent(Intent.ACTION_SEND).apply{
                                        type="text/plain"
                                        putExtra(Intent.EXTRA_TEXT,
                                            "[CÔNG VIỆC HẰNG NGÀY]\nVấn đề: ${x.text}\nHạn: ${x.due}\nTiến độ: ${x.progress}%")
                                    }
                                    ctx.startActivity(Intent.createChooser(i,"Chia sẻ vấn đề"))
                                }){Text("Chia sẻ")}
                            }
                        }}
                    }
                }
            }
            2->Column(Modifier.padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                Text("Tổng quan",style=MaterialTheme.typography.headlineSmall)
                Stat("Ca",shift); Stat("Hoàn thành","$done/18")
                Stat("Tồn đọng","${todos.count{!it.done}}")
                Stat("Đến hạn hôm nay","$dueToday"); Stat("Quá hạn","$overdue")
                Text("Công Việc Hằng Ngày v2.0")
            }
        }
    }
}
@Composable fun Stat(a:String,b:String){
    Card(Modifier.fillMaxWidth()){Row(
        Modifier.padding(16.dp).fillMaxWidth(),
        horizontalArrangement=Arrangement.SpaceBetween
    ){Text(a);Text(b,style=MaterialTheme.typography.titleMedium)}}
}
